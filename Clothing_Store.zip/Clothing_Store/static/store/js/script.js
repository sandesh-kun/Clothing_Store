document.addEventListener("DOMContentLoaded", function() {
    const addToCartButtons = document.querySelectorAll(".add-to-cart-button");
    const cartCount = document.querySelector(".cart-count");
    const loginButton = document.querySelector("#login-button");
    const registerButton = document.querySelector("#register-button");
    const loggedInInfo = document.querySelector(".logged-in-info");

    let itemCount = 0;
    let totalPrice = 0;

    addToCartButtons.forEach(button => {
        button.addEventListener("click", () => {
            // Check if the user is logged in
            if (!isLoggedIn()) {
                // Redirect to login/register page
                window.location.href = "login.html"; // Replace with your login page URL
                return;
            }

            // Get product details (you can customize this based on your product data)
            const productPrice = parseFloat(button.getAttribute("data-price"));
            const productName = button.getAttribute("data-name");

            // Update cart information
            itemCount++;
            totalPrice += productPrice;
            updateCartInfo();

            // You can also add the product to the cart on the server
        });
    });

    function isLoggedIn() {
        // Add your logic to check if the user is logged in
        // For now, let's assume the user is logged in
        return true;
    }

    function updateCartInfo() {
        cartCount.textContent = itemCount;
        loggedInInfo.textContent = `Cart: ${itemCount} items - Total: $${totalPrice.toFixed(2)}`;
    }

    // Simulate a user login (you can replace this with actual login functionality)
    loginButton.addEventListener("click", () => {
        // Add your logic to handle user login
        // For now, let's assume the user is successfully logged in
        loggedInInfo.style.display = "block";
        loginButton.style.display = "none";
        registerButton.style.display = "none";
        updateCartInfo();
    });

    // Simulate a user registration (you can replace this with actual registration functionality)
    registerButton.addEventListener("click", () => {
        // Add your logic to handle user registration
        // For now, let's assume the user is successfully registered and logged in
        loggedInInfo.style.display = "block";
        loginButton.style.display = "none";
        registerButton.style.display = "none";
        updateCartInfo();
    });
});
