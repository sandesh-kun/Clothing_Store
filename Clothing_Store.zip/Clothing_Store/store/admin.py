from django.contrib import admin
from .models import *


# Register your models here.

admin.site.register(man)
admin.site.register(women)
admin.site.register(Varify)
admin.site.register(Cart)
admin.site.register(CartItem)