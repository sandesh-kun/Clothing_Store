from django.db import models
from django.contrib.auth.models import User
import phonenumbers
from django.core.exceptions import ValidationError
from django.urls import reverse

# Create your models here.

class man(models.Model):
    title = models.CharField(max_length=100, default=True)
    clothes_size = (
        ('L','Large'),
        ('M','Medium'),
        ('S','Small')
    )
    size = models.CharField(max_length=10, choices= clothes_size, default=True)
    price = models.CharField(max_length=100, default=True)
    image = models.ImageField(default = True, upload_to='products/')
    
    def __str__(self):
        return self.title

class women(models.Model):
    title = models.CharField(max_length=100, default=True)
    clothes_size = (
        ('L','Large'),
        ('M','Medium'),
        ('S','Small')
    )
    size = models.CharField(max_length=10, choices= clothes_size, default=True)
    price = models.CharField(max_length=100, default=True)
    image = models.ImageField(default = True, upload_to='products/')
    
    def __str__(self):
        return self.title

class Varify(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    otp = models.CharField(max_length=4,blank=True, null=True)
    is_varified = models.BooleanField(default=False)


class Profile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    phone_no = models.CharField(max_length=20, unique=True)
    address = models.CharField(max_length=255)
    GENDER_CHOICES = (
        ('M', 'Male'),
        ('F', 'Female'),
        ('O', 'Other'),
    )
    gender = models.CharField(max_length=1, choices=GENDER_CHOICES)
    profile_pics = models.ImageField(upload_to='profile_pics/', default='')

    def clean(self):
        super().clean()
        try:
            parsed_number = phonenumbers.parse(self.phone_no, 'NP')
            if not phonenumbers.is_valid_number(parsed_number):
                raise ValidationError('Invalid phone number.')
            self.phone_no = phonenumbers.format_number(parsed_number, phonenumbers.PhoneNumberFormat.E164)
        except phonenumbers.phonenumberutil.NumberParseException:
            raise ValidationError('Invalid phone number.')

    def __str__(self):
        return self.user.username
    

class Cart(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)

class CartItem(models.Model):
    cart = models.ForeignKey(Cart, on_delete=models.CASCADE)
    product = models.ForeignKey(man, on_delete=models.CASCADE)
    quantity = models.IntegerField(default=1)

    def __str__(self):
        return f"{self.product.title} (x{self.quantity})"
    
class Payments(models.Model):
    pidx = models.CharField(max_length=100, unique=True)
    code = models.CharField(max_length=200, null= True,blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.pidx
    
class Bill(models.Model):
    users = models.ForeignKey(User, on_delete=models.CASCADE)
    bill_no = models.AutoField(primary_key=True)
    product_name = models.CharField(max_length=100)
    product_price = models.CharField(max_length=20)
    seller_name = models.CharField(max_length=100, default="Clothing Store")
    seller_address = models.CharField(max_length=100, default="Kathmandu, Nepal")
    seller_contact = models.CharField(max_length=20, default="98xxxxxxxx")
    buyer_name = models.CharField(max_length=100)
    buyer_contact = models.CharField(max_length=20)
    buyer_address = models.CharField(max_length=100)

    def __str__(self):
        return self.product_name
    
class Purchase(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    product_name = models.CharField(max_length=100)
    price = models.IntegerField()
    purchase_id = models.CharField(max_length=200, null=True, blank=True)
    txns_id = models.CharField(max_length=200, null=True, blank=True)
    buyer_fname = models.CharField(max_length=100)
    buyer_lname = models.CharField(max_length=100)
    buyer_email = models.EmailField()
    buyer_phone = models.CharField(max_length=100)
    product = models.ForeignKey(CartItem, on_delete=models.CASCADE)

    def __str__(self):
        return self.product_name
    
    def get_absolute_url(self):
        return reverse('product_detail', args=[str(self.product.id)])