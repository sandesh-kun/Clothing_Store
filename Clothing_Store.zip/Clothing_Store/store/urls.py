from django.urls import path
from . import views

urlpatterns = [
    path('home/', views.home, name= 'home'),
    path('', views.home, name='home'),
    path('men/', views.men_view, name='men'),
    path('women/', views.women_view, name='women'),
    path('verify/<str:email>', views.send_verify_mail, name='send_verify_mail'),
    path('verify_otp/<str:email>',views.Email_otp_verify, name= 'email_otp_verify'),
    path('register' , views.register_attempt , name="registration"),
    path('login', views.login_attempt, name='login'),
    path('forget-pass/',views.forget_pass, name='forget'),
    path('forget_otp/<str:email>',views.forget_pass_otp, name='forget_otp'),
    path('create/<str:email>', views.create_pass, name='create'),
    path('custom_login', views.custom_login, name='custom_login'),
    path('profile_edit', views.profile_edit, name='profile_edit'),
    path('profile/', views.profile, name = 'profile'),
    path('logout/', views.logout_user, name = 'logout'),
    path('logout' , views.logout_attempt , name="logout"),
    path('otp', views.Verify_otp, name='otps'),
    path('add_to_cart/<str:product_ids>/', views.add_multiple_products_to_cart, name='add_to_cart'),
    path('view_cart/', views.view_cart, name='view_cart'),
    # path('bill/<int:pk>', views.bill, name='bill'),
    path('bill/', views.bill, name='bill'),
    path('error', views.error, name='error')


    
]
