from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from . models import *

class CreateUserForm(UserCreationForm):
    class Meta:
        model = User
        fields = ['username', 'first_name','last_name','email', 'password1', 'password2']

class ProfileForm(forms.ModelForm):
    phone_no = forms.CharField(max_length=20)
    address = forms.CharField(max_length=255)
    gender = forms.ChoiceField(choices=Profile.GENDER_CHOICES)
    profile_pics = forms.ImageField(required=False)

    class Meta:
        model = Profile
        fields = ['phone_no', 'address', 'gender', 'profile_pics']
        

    def __init__(self, *args, **kwargs):
        super(ProfileForm, self).__init__(*args, **kwargs)
        self.fields['phone_no'].widget.attrs.update({'class': 'form-control'})
        self.fields['address'].widget.attrs.update({'class': 'form-control'})
        self.fields['gender'].widget.attrs.update({'class': 'form-control'})
        self.fields['profile_pics'].widget.attrs.update({'class': 'form-control'})