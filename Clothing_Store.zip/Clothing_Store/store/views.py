from django.http import HttpResponse
from django.shortcuts import render, redirect,get_object_or_404
from django.contrib.auth import views as auth_views 
from django.contrib.auth.models import User
from django.contrib.auth.models import User
from django.views.generic.edit import CreateView  # Import CreateView
from django.shortcuts import render, redirect
from django.urls import reverse
from django.contrib.auth import authenticate, login, logout
from django.views.generic.edit import FormView
from .models import *
import random
from django.core.mail import send_mail
from .forms import *
from django.contrib.auth.decorators import login_required
from .decorators import varify_required
from django.contrib import messages 
import requests
from django.conf import settings
from django.core.exceptions import ObjectDoesNotExist

def home(request):
    men = man.objects.all()[:6]
    wmen = women.objects.all()[:3]
    context = {
        'men':men,
        'wmen':wmen,
    }
    return render(request, 'index.html', context)


def men_view(request):
    men = man.objects.all()[:12]
    context = {'men':men}
    return render(request, 'men.html',context)

def women_view(request):
    wmen = women.objects.all()[:12]
    context = {'wmen':wmen}
    return render(request, 'women.html', context)


def login_attempt(request):
    if request.method == "POST":
        email = request.POST.get('email')
        password = request.POST.get('password')
        print(email)
        user = User.objects.filter(email = email).first()
        if not user:
            message = {'error' : 'user does not exist'}
            context = message
            return render(request, 'login.html', context)

        verify = Varify.objects.filter(user=user).first()
        if not verify or not verify.is_varified:
            message = {'error': 'your account is not verified'}
            context = message
            return render(request, 'login.html', context)

        user = authenticate(username=email, password=password)
        print(user)
        if user is not None:
            print("login")
            login(request, user)
            return redirect('custom_login')
        else:
            message = {'error' : 'invalid credentials'}
            context = message
            return render(request, 'login.html', context)
    return render(request, 'login.html')
        

def custom_login(request):
    if request.user.is_authenticated and not Profile.objects.filter(user=request.user).exists():
        return redirect('profile_edit')
    else:
        return redirect('/')
    
@login_required(login_url='login')
def profile(request):
    user = request.user
    profile = user.profile
    return render(request, 'profile.html', {'user': user, 'profile': profile})
    
    
@login_required(login_url='login')
def profile_edit(request):
    if request.method == 'POST':
        form = ProfileForm(request.POST, request.FILES)
        if form.is_valid():
            profile = form.save(commit=False)
            profile.user = request.user
            profile.save()
            return redirect('home')
    else:
        form = ProfileForm()
    return render(request, 'profile_edit.html', {'form': form})

@login_required(login_url='login')
def send_otp(request):
    current_user = request.user
    email = request.user.email
    gen_otp = random.randint(1000, 9999)

    # Fetch an existing Varify object or create a new one
    hello, created = Varify.objects.get_or_create(user=current_user)

    # Update the OTP for the Varify object
    hello.otp = gen_otp
    hello.save()

    subject = f'OTP'
    message = f'Your otp is {gen_otp}'
    from_email = 'sandeshstone13@gmail.com'
    recipient_email = [email]
    send_mail(subject, message, from_email, recipient_email)

    return HttpResponse('Email sent successfully')
    

@login_required
def Verify_otp(request):
    user = request.user
    if request.method == 'POST':
        user_otp = request.POST.get('otp')

        if user_otp == user.varify.otp:
            user.varify.is_varified = True
            user.varify.save()
            return redirect('home')
        else:
            message = "Invalid OTP"
            return render(request, 'otp.html', {'message':message})
    return render(request, 'otp.html')


def register_attempt(request):
    if request.method == 'POST':
        f_name = request.POST.get('f_name')
        l_name = request.POST.get('l_name')
        email = request.POST.get('email')
        password = request.POST.get('password')
        
        user = User.objects.filter(email = email).first()
        
        if user:
            message = {'error' : 'user already exists'}
            context = message
            return render(request, 'register.html', context)
        user = User(first_name = f_name , last_name = l_name , email = email , username=email)
        user.set_password(password)
        user.save()
        return redirect('send_verify_mail', email = email)
    
    return render(request, 'register.html')


def send_verify_mail(request, email):
    if request.method == 'POST':
        email = request.POST.get('email')
        gen_otp = random.randint(1000, 9999)
        users = User.objects.get(email = email)
        subject = f'OTP'
        message = f'Your Otp is {gen_otp}'
        from_email = 'sandeshstone13@gmail.com'
        recipient = [email]
        send_mail(subject, message, from_email, recipient)

        hello = Varify()
        hello.user = users
        hello.otp = gen_otp
        hello.save()
        return redirect('email_otp_verify', email = email)
    return render(request, 'send_verify_mail.html', {'email':email})

def Email_otp_verify(request,email):
    users = User.objects.get(email = email)
    if request.method == 'POST':
        user_otp = request.POST.get('otp')
        if user_otp == users.varify.otp:
            users.varify.is_varified = True
            users.varify.otp = 0000
            users.varify.save()
            return redirect('login')
        else:
            message = "Invalid OTP"
            return render(request, 'email_otp_verify.html', {'message':message})
    return render(request, 'email_otp_verify.html')


def forget_pass(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        gen_otp = random.randint(1000, 9999)
        users = User.objects.get(email = email)
        subject = f'OTP'
        message = f'Your Otp is {gen_otp}'
        from_email = 'sandeshstone13@gmail.com'
        recipient = [email]
        send_mail(subject, message, from_email, recipient)

        varify_instance = Varify.objects.get(user=users)
        varify_instance.otp = gen_otp
        varify_instance.save()
        return redirect('forget_otp', email = email)

    return render(request, 'forget_pass.html')

def forget_pass_otp(request,email):
    users = User.objects.get(email = email)
    if request.method == 'POST':
        user_otp = request.POST.get('otp')
        if user_otp == users.varify.otp:
            users.varify.otp = 0000
            users.varify.save()
            return redirect('create', email = email)
        else:
            message = "Invalid OTP"
            return render(request, 'forget_pass_otp.html', {'message':message})
    return render(request, 'forget_pass_otp.html')

def create_pass(request, email):
    users = User.objects.get(email = email)
    if request.method == 'POST':
        password = request.POST.get('password')
        users.set_password(password)
        users.save()
        return redirect('login')

    return render(request, 'create_pass.html')

@login_required(login_url='login')
def logout_user(request):
    logout(request)
    messages.info(request, 'You logged out successfully')
    return redirect('home')

def logout_attempt(request):
    logout(request)
    return redirect('/')


@login_required(login_url='login')
def update_profile(request,pk):
    profile = get_object_or_404(Profile, pk=pk)

    if request.method == 'POST':
        form = ProfileForm(request.POST, request.FILES, instance=profile)
        if form.is_valid():
            form.save()
            return redirect('profile')
    else:
        form = ProfileForm(instance=profile) if profile else None

    return render(request, 'update_profile.html', {'form': form})


def add_multiple_products_to_cart(request, product_ids):
    user = request.user
    cart, created = Cart.objects.get_or_create(user=user)

    for product_id in product_ids.split(','):  # Split by comma if you pass multiple IDs
        try:
            product = man.objects.get(pk=product_id)  # Correct the model name
        except man.DoesNotExist:
            return HttpResponse(f"Product with id {product_id} does not exist.", status=404)

        cart_item, created = CartItem.objects.get_or_create(cart=cart, product=product)
        
        if not created:
            cart_item.quantity += 1  
        
        cart_item.save()
    return redirect('home')

def view_cart(request):
    user = request.user
    total_sum = 0
    total_price = 0
    try:
        cart = Cart.objects.get(user=user)
        cart_items = CartItem.objects.filter(cart=cart)
        
        for i in cart_items:
            quantity = int(i.quantity)
            price = float(i.product.price)
            total_price = quantity * price
            total_sum += total_price

    except Cart.DoesNotExist:
        cart = None
        cart_items = []

    return render(request, 'view_cart.html', {'cart_items': cart_items, 'total_price': total_price, 'total_sum': total_sum})



@login_required(login_url='login')
def bill(request,pk):
    cart = Cart.objects.get(user=user)
    eachproduct = CartItem.objects.filter(cart=cart)
    first_name = request.user.first_name
    last_name = request.user.last_name
    address = request.user.profile.address
    phone = request.user.profile.phone_no
    user = request.user
    
    total_sum = 0
    total_price = 0
    
        
    for i in eachproduct:
        quantity = int(i.quantity)
        price = float(i.product.price)
        total_price = quantity * price
        total_sum += total_price

    amount = total_sum
    price = amount *100


    data = {
    "return_url" : "http://127.0.0.1:8000/success/",
    "website_url": " http://127.0.0.1:8000/",
    "amount": price,
    "purchase_order_id": eachproduct.id,
    "purchase_order_name": eachproduct.name,
    "customer_info": {
        "name": user.first_name,
        "email": user.email,
    },
    "amount_breakdown": [
        {
            "label": "Mark Price",
            "amount": price
        },
        {
            "label": "VAT",
            "amount": 0
        }
    ],
    "product_details": [
        {
            "identity": eachproduct.id,
            "name": eachproduct.name,
            "total_price": price,
            "quantity": 1,
    "unit_price": price
        }
    ]
    }
    headers = {
        "Authorization": "Key 0897dccb486b469694dd327a33efb8d8"  
    }  
    response= requests.post("https://a.khalti.com/api/v2/epayment/initiate/", json=data, headers = headers)
    if response.status_code==200:
        data= response.json() 
        pidx= data.get('pidx')
        pay= data.get("payment_url")
        payment = Payments.objects.create(pidx=pidx)
        context = {'eachproduct':eachproduct, 'first_name':first_name, 'last_name':last_name, 'address':address, 'phone':phone, 'pay': pay}

        return render(request, 'bill.html', context)
    else:
        # Return an error message if the request was not successful
        return render(request, 'error.html', {'message': 'Failed to get response from Khalti API'})
    
def success(request):
    pk = request.GET.get('purchase_order_id')
    p_name = request.GET.get('purchase_order_name')
    amount = request.GET.get('amount')
    amount = int(amount)/100
    phone = request.GET.get('mobile')
    txn_id = request.GET.get('transaction_id')
    cart = Cart.objects.get(pk=pk)
    eachproduct = CartItem.objects.get(cart=cart)
    # purchase = Purchase.objects.filter(product = eachproduct)
    current_user = request.user
    f_name = request.user.first_name
    l_name = request.user.last_name
    successful_purchase = Purchase()
    successful_purchase.product_name = eachproduct.name
    successful_purchase.price = eachproduct.price
    successful_purchase.purchase_id = pk
    successful_purchase.txns_id = txn_id
    successful_purchase.buyer_fname = current_user.first_name
    successful_purchase.buyer_lname = current_user.last_name
    successful_purchase.buyer_email = current_user.email
    successful_purchase.buyer_phone = current_user.profile.phone_no
    successful_purchase.product = eachproduct
    successful_purchase.user = current_user
    s_name = "Clothing Store"
    s_Contact ="98xxxxxxxx"
    s_email = "sandeshstonedxd@gmail.com"
    b_email = request.user.email
    b_fname = current_user.first_name
    b_lname = current_user.last_name
    success_email_buyer(s_email,b_email,amount,txn_id,s_name,s_Contact,s_email,b_fname,b_lname)


    successful_purchase.save()
    eachproduct.save()
 
    context = {'eachproduct': eachproduct, 'successful_purchase': successful_purchase,'pk':pk, 'p_name':p_name, 'amount':amount, 'txn_id':txn_id, 'phone':phone, 'f_name':f_name, 'l_name':l_name}
    return render(request, 'success.html', context)

def success_email_buyer(s_email,b_email,amount,txn_id,s_name,s_Contact,b_fname,b_lname):
    subject = f'Purchase Message from Second Hand Online Market'
    message = f'Name: {b_fname} {b_lname}\n Price:{amount}\n Transaction Id: {txn_id}\n Seller: {s_name} \n Seller Contact: {s_Contact} \n Seller Contact: {s_Contact}\n Seller Email: {s_email}\n Payment Successful.'

    from_email = 'sandeshstone13@gmail.com'
    recipient_email = [b_email]
    send_mail(subject, message, from_email, recipient_email)

    return HttpResponse('Email Sent Successfully')



@login_required(login_url='login')
def bill(request):
    try:
        cart = Cart.objects.get(user=request.user)
        eachproduct = CartItem.objects.filter(cart=cart)
    except Cart.DoesNotExist:
        return render(request, 'error.html', {'message': 'Cart does not exist'})
    
    try:
        user_profile = request.user.profile
        address = user_profile.address
        phone = user_profile.phone_no
    except ObjectDoesNotExist:
        return render(request, 'error.html', {'message': 'User profile does not exist'})
    
    first_name = request.user.first_name
    last_name = request.user.last_name
    user = request.user

    try:
        total_sum = sum(float(item.product.price) * int(item.quantity) for item in eachproduct)
    except (ValueError, TypeError):
        return render(request, 'error.html', {'message': 'Invalid product data'})
    
    price = int(total_sum * 100)  # Assuming the conversion is to cents

    data = {
        "return_url": "http://127.0.0.1:8000/success/",
        "website_url": "http://127.0.0.1:8000/",
        "amount": price,
        "purchase_order_id": cart.id,  # Changed to cart.id since eachproduct is a list
        "purchase_order_name": "Cart Items",  # General name for the entire cart
        "customer_info": {
            "name": user.first_name,
            "email": user.email,
        },
        "amount_breakdown": [
            {
                "label": "Mark Price",
                "amount": price
            },
            {
                "label": "VAT",
                "amount": 0
            }
        ],
        "product_details": [
            {
                "identity": item.product.id,
                "name": item.product.title,
                "total_price": item.product.price * item.quantity,
                "quantity": item.quantity,
                "unit_price": item.product.price
            }
            for item in eachproduct
        ]
    }

    headers = {
        "Authorization": "key 3b0c6b2241ac4e34bd5b575d4f166137"
    }

    try:
        response = requests.post("https://a.khalti.com/api/v2/epayment/initiate/", json=data, headers=headers)
        response.raise_for_status()
        data = response.json()
    except requests.RequestException as e:
        return render(request, 'error.html', {'message': f"Failed to get response from Khalti API: {e}"})

    if response.ok:
        pidx = data.get('pidx')
        pay = data.get("payment_url")
        Payments.objects.create(pidx=pidx)
        context = {'eachproduct': eachproduct, 'first_name': first_name, 'last_name': last_name, 'address': address, 'phone': phone, 'pay': pay}
        return render(request, 'bill.html', context)


def error(request):
    return render(request, 'error.html')