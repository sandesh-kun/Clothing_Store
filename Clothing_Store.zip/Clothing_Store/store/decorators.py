from django.shortcuts import redirect


def unauthenticated_user(view_func):
    def wrapper_func(request, *args, **kwargs):

        if request.user.is_authenticated:
            return redirect('home')
        else:
            return view_func(request, *args, **kwargs)
    
    return wrapper_func

# def varify_required(view_func):
#     def wrapper(request, *args, **kwargs):
#         if request.user.is_authenticated:
#             if request.user.varify.is_varified:
#                 return view_func(request, *args, **kwargs)
#             else:
#                 return redirect('before_verify')
#         else:
#             return redirect('login')
#     return wrapper

def varify_required(view_func):
    def wrapper(request, *args, **kwargs):
        if request.user.is_authenticated:
            try:
                if request.user.varify.is_varified:
                    return view_func(request, *args, **kwargs)
                else:
                    return redirect('varify_otp')
            except AttributeError:
                return redirect('before_verify')
        else:
            return redirect('login')
    return wrapper